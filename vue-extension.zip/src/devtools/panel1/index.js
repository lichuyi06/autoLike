import Vue from "vue";
import AppComponent from "./App/App.vue";
import 'element-ui/lib/theme-chalk/index.css';

Vue.component("app-component", AppComponent);

// 新添
import {
  Card,
  Button
} from 'element-ui';

// 新添
Vue.use(Card);
Vue.use(Button);

new Vue({
  el: "#app",
  render: createElement => {
    return createElement(AppComponent);
  }
});
