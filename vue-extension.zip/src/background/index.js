/*
 * @Author: Penk
 * @LastEditors: Penk
 * @LastEditTime: 2022-07-01 14:37:38
 * @FilePath: \vue-extension\src\background\index.js
 */
function init(){
  console.log("Hello background...");
}

init();
